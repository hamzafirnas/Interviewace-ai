import React from 'react';
import { InterviewSetup, AppView } from '../types/interview';
import { Sparkles, Award, RotateCcw, BookOpen, User } from 'lucide-react';

interface NavbarProps {
  currentView: AppView;
  setup: InterviewSetup;
  currentQAIndex: number;
  totalQuestions: number;
  averageScore?: number;
  onNavigate: (view: AppView) => void;
  onOpenStarGuide: () => void;
  onResetSession: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setup,
  currentQAIndex,
  totalQuestions,
  averageScore,
  onNavigate,
  onOpenStarGuide,
  onResetSession
}) => {
  return (
    <nav className="flex justify-between items-center h-16 px-4 md:px-8 bg-white/50 backdrop-blur-md border border-white/30 rounded-2xl shadow-sm mb-6 transition-all">
      {/* Brand Logo */}
      <button 
        onClick={() => onNavigate('home')}
        className="flex items-center gap-3 group text-left cursor-pointer focus:outline-none"
      >
        <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition-all transform group-hover:scale-105">
          <div className="w-4 h-4 border-2 border-white rotate-45 rounded-xs" />
        </div>
        <div>
          <span className="text-xl font-bold tracking-tight text-blue-950 block leading-tight">
            InterviewAce <span className="text-blue-600">AI</span>
          </span>
          <span className="text-[10px] font-semibold tracking-wider text-slate-500 uppercase block">
            HR Coaching for Graduates
          </span>
        </div>
      </button>

      {/* Candidate Status Badge (when in interview or setup) */}
      {setup.userName && (currentView === 'interview' || currentView === 'summary') && (
        <div className="hidden md:flex items-center gap-4 bg-white/60 px-4 py-1.5 rounded-xl border border-white/60 text-xs font-medium text-slate-700 shadow-xs">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs border border-blue-200">
              {setup.userName.charAt(0).toUpperCase()}
            </div>
            <span><strong className="text-blue-900">{setup.userName}</strong></span>
          </div>
          <div className="h-4 w-px bg-slate-300/60" />
          <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-[10px] rounded-md font-bold uppercase tracking-wide">
            {setup.difficulty}
          </span>
          {averageScore !== undefined && averageScore > 0 && (
            <>
              <div className="h-4 w-px bg-slate-300/60" />
              <div className="flex items-center gap-1 text-slate-600">
                <Award className="w-3.5 h-3.5 text-amber-500" />
                <span className="font-bold text-blue-900">{averageScore.toFixed(1)}/10</span>
              </div>
            </>
          )}
        </div>
      )}

      {/* Navigation & Action Buttons */}
      <div className="flex items-center gap-2 md:gap-3">
        <button
          onClick={onOpenStarGuide}
          className="flex items-center gap-1.5 px-3 py-2 bg-white/70 hover:bg-white text-slate-700 text-xs font-semibold rounded-xl border border-slate-200/80 shadow-2xs transition-all cursor-pointer"
          title="Learn the STAR Response Method"
        >
          <BookOpen className="w-3.5 h-3.5 text-blue-600" />
          <span className="hidden sm:inline">STAR Guide</span>
        </button>

        {currentView === 'interview' && (
          <button
            onClick={onResetSession}
            className="flex items-center gap-1 px-3 py-2 text-slate-500 hover:text-red-600 hover:bg-red-50 text-xs font-semibold rounded-xl transition-all cursor-pointer"
            title="Start New Interview"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        )}

        {currentView === 'home' && (
          <button
            onClick={() => onNavigate('setup')}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Start Practice</span>
          </button>
        )}
      </div>
    </nav>
  );
};
