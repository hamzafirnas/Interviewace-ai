import React, { useState } from 'react';
import { InterviewSetup, DifficultyLevel, JobCategory } from '../types/interview';
import { User, Sparkles, ArrowRight, ShieldAlert, Check, Layers } from 'lucide-react';

interface SetupPageProps {
  initialSetup: InterviewSetup;
  onStartInterview: (setup: InterviewSetup) => void;
  onBackToHome: () => void;
}

const DIFFICULTIES: { level: DifficultyLevel; description: string; color: string; badge: string }[] = [
  {
    level: 'Beginner',
    description: 'Standard HR questions (Self-intro, strengths, motivation, basic teamwork). Friendly AI evaluation.',
    color: 'border-green-300 bg-green-50/40 hover:bg-green-50/80 text-green-950',
    badge: 'bg-green-100 text-green-700'
  },
  {
    level: 'Intermediate',
    description: 'Behavioral & situation questions (Conflict resolution, tight deadlines, adaptability). Standard STAR evaluation.',
    color: 'border-blue-300 bg-blue-50/40 hover:bg-blue-50/80 text-blue-950',
    badge: 'bg-blue-100 text-blue-700'
  },
  {
    level: 'Advanced',
    description: 'High-stakes scenarios (Navigating ambiguity, stakeholder management, strategic leadership). Rigorous AI grading.',
    color: 'border-purple-300 bg-purple-50/40 hover:bg-purple-50/80 text-purple-950',
    badge: 'bg-purple-100 text-purple-700'
  }
];

const JOB_CATEGORIES: JobCategory[] = [
  'General HR & Campus Hire',
  'Software Engineering & Tech',
  'Business Development & Marketing',
  'Finance & Accounting',
  'Management Trainee & Ops'
];

export const SetupPage: React.FC<SetupPageProps> = ({ initialSetup, onStartInterview, onBackToHome }) => {
  const [userName, setUserName] = useState(initialSetup.userName || '');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>(initialSetup.difficulty || 'Intermediate');
  const [category, setCategory] = useState<JobCategory>(initialSetup.category || 'General HR & Campus Hire');
  const [questionCount, setQuestionCount] = useState<number>(initialSetup.questionCount || 5);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) {
      setError('Please enter your name to personalize your interview evaluation.');
      return;
    }
    setError('');
    onStartInterview({
      userName: userName.trim(),
      difficulty,
      category,
      questionCount
    });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div className="bg-white/80 backdrop-blur-lg border border-white/60 rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="text-center mb-8 space-y-2">
          <span className="text-xs font-bold text-blue-600 uppercase tracking-widest block">Step 1 of 2</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Set Up Your AI Interview</h2>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Customize candidate profile and difficulty level to receive tailored HR interview questions.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* User Name Input */}
          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" />
              <span>Your Full Name</span>
              <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={userName}
              onChange={(e) => {
                setUserName(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Alex Johnson"
              className="w-full px-4 py-3 bg-white/80 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-slate-900 font-medium placeholder-slate-400 shadow-2xs transition-all"
            />
            {error && (
              <p className="text-xs font-medium text-red-600 flex items-center gap-1 mt-1">
                <ShieldAlert className="w-3.5 h-3.5" /> {error}
              </p>
            )}
          </div>

          {/* Difficulty Level Selection */}
          <div className="space-y-3">
            <label className="block text-sm font-bold text-slate-700">
              Select Interview Difficulty
            </label>
            <div className="grid grid-cols-1 gap-3">
              {DIFFICULTIES.map((item) => {
                const isSelected = difficulty === item.level;
                return (
                  <div
                    key={item.level}
                    onClick={() => setDifficulty(item.level)}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-start gap-4 ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/60 shadow-sm'
                        : 'border-slate-200/80 bg-white/50 hover:bg-white/80 hover:border-slate-300'
                    }`}
                  >
                    <div className={`mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                      isSelected ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300'
                    }`}>
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-sm">{item.level}</span>
                        <span className={`px-2 py-0.5 text-[10px] rounded-md font-bold uppercase ${item.badge}`}>
                          {item.level}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">{item.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Job Category Focus */}
          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-700 flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-600" />
              <span>Target Role / Industry Focus</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as JobCategory)}
              className="w-full px-4 py-3 bg-white/80 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-slate-900 font-medium shadow-2xs transition-all cursor-pointer"
            >
              {JOB_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Number of Questions */}
          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-700">
              Session Length (Number of Questions)
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[3, 5, 7].map((count) => (
                <button
                  type="button"
                  key={count}
                  onClick={() => setQuestionCount(count)}
                  className={`py-3 rounded-xl border font-bold text-sm transition-all cursor-pointer ${
                    questionCount === count
                      ? 'border-blue-600 bg-blue-600 text-white shadow-sm'
                      : 'border-slate-200 bg-white/60 text-slate-700 hover:bg-white'
                  }`}
                >
                  {count} Questions
                </button>
              ))}
            </div>
          </div>

          {/* Submit Actions */}
          <div className="pt-4 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={onBackToHome}
              className="w-full sm:w-1/3 py-3.5 bg-white border border-slate-200 text-slate-700 font-bold text-sm rounded-xl hover:bg-slate-50 transition-all cursor-pointer text-center"
            >
              Back
            </button>
            <button
              type="submit"
              className="w-full sm:w-2/3 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Begin AI Interview</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
