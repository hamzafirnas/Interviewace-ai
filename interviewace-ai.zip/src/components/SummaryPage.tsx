import React, { useState, useEffect } from 'react';
import { InterviewSetup, InterviewQA, InterviewSummaryReport } from '../types/interview';
import { generateSummaryWithGemini } from '../services/geminiService';
import { Award, CheckCircle2, AlertTriangle, Sparkles, RotateCcw, ChevronDown, ChevronUp, Download, ArrowRight, ShieldCheck, Check } from 'lucide-react';

interface SummaryPageProps {
  setup: InterviewSetup;
  qaList: InterviewQA[];
  onRestartSameSetup: () => void;
  onNewInterview: () => void;
}

export const SummaryPage: React.FC<SummaryPageProps> = ({
  setup,
  qaList,
  onRestartSameSetup,
  onNewInterview
}) => {
  const [report, setReport] = useState<InterviewSummaryReport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  useEffect(() => {
    let isMounted = true;

    async function loadSummary() {
      setIsLoading(true);
      const res = await generateSummaryWithGemini(
        setup.userName,
        setup.difficulty,
        setup.category,
        qaList
      );
      if (isMounted) {
        setReport(res);
        setIsLoading(false);
      }
    }

    loadSummary();

    return () => {
      isMounted = false;
    };
  }, [setup, qaList]);

  // Calculate scores directly as fallback
  const scores = qaList.map(q => q.evaluation?.score || 0);
  const averageScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 8.0;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in pb-12">
      {/* Top Banner */}
      <section className="bg-white/80 backdrop-blur-lg border border-white/60 rounded-3xl p-6 sm:p-8 shadow-md text-center relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-blue-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 space-y-3 max-w-xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-bold uppercase tracking-wider">
            <CheckCircle2 className="w-3.5 h-3.5" /> Interview Completed
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Performance Summary for <span className="text-blue-600">{setup.userName || 'Candidate'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-600">
            Target Level: <strong className="text-slate-900">{setup.difficulty}</strong> · Focus: <strong className="text-slate-900">{setup.category}</strong>
          </p>
        </div>
      </section>

      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white/60 backdrop-blur-md border border-white/40 rounded-3xl p-6 shadow-xs text-center space-y-1">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Average Score</p>
          <p className="text-3xl sm:text-4xl font-black text-blue-900">
            {averageScore.toFixed(1)}
            <span className="text-base font-normal text-slate-400">/10</span>
          </p>
          <p className="text-[11px] text-slate-500">Across {qaList.length} answered questions</p>
        </div>

        <div className="bg-white/60 backdrop-blur-md border border-white/40 rounded-3xl p-6 shadow-xs text-center space-y-1">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Questions Answered</p>
          <p className="text-3xl sm:text-4xl font-black text-slate-900">
            {qaList.length}
            <span className="text-base font-normal text-slate-400">/{setup.questionCount}</span>
          </p>
          <p className="text-[11px] text-slate-500">Completed session</p>
        </div>

        <div className="bg-blue-600 text-white rounded-3xl p-6 shadow-md text-center space-y-1 relative overflow-hidden">
          <p className="text-xs font-semibold text-blue-200 uppercase tracking-widest">Campus Readiness</p>
          <p className="text-lg font-extrabold text-white truncate">
            {report?.readinessRating || 'High Potential'}
          </p>
          <p className="text-[11px] text-blue-100">AI Placement Assessment</p>
          <div className="absolute -bottom-4 -right-4 w-20 h-20 bg-blue-400/20 rounded-full blur-xl" />
        </div>
      </div>

      {/* AI Detailed Executive Feedback */}
      <section className="bg-white/80 backdrop-blur-lg border border-white/60 rounded-3xl p-6 sm:p-8 shadow-md space-y-6">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Sparkles className="w-5 h-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-900">Overall AI Interview Assessment</h2>
        </div>

        {isLoading ? (
          <div className="py-8 text-center text-sm text-slate-500 animate-pulse">
            Generating holistic candidate evaluation report...
          </div>
        ) : (
          <div className="space-y-6">
            <p className="text-sm text-slate-700 leading-relaxed bg-slate-50/60 p-4 rounded-2xl border border-slate-100 font-medium">
              "{report?.overallFeedback}"
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Key Strengths */}
              <div className="bg-green-50/40 rounded-2xl p-4 border border-green-200/60 space-y-2">
                <h3 className="text-xs font-bold text-green-800 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-green-600" /> Top Candidate Strengths
                </h3>
                <ul className="space-y-1.5 text-xs text-slate-700 list-disc pl-5">
                  {report?.topStrengths.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>

              {/* Areas to Improve */}
              <div className="bg-amber-50/40 rounded-2xl p-4 border border-amber-200/60 space-y-2">
                <h3 className="text-xs font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600" /> Primary Areas to Improve
                </h3>
                <ul className="space-y-1.5 text-xs text-slate-700 list-disc pl-5">
                  {report?.areasToImprove.map((a, idx) => (
                    <li key={idx}>{a}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Action Steps */}
            {report?.actionSteps && report.actionSteps.length > 0 && (
              <div className="bg-blue-50/40 rounded-2xl p-4 border border-blue-100/80 space-y-2">
                <h3 className="text-xs font-bold text-blue-800 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-blue-600" /> Recommended Action Steps for Placement Success
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  {report.actionSteps.map((step, idx) => (
                    <div key={idx} className="bg-white/80 p-3 rounded-xl border border-white/80 text-xs text-slate-700 shadow-2xs">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 font-bold text-[10px] inline-flex items-center justify-center mr-1.5">
                        {idx + 1}
                      </span>
                      {step}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Question-by-Question Detailed Breakdown */}
      <section className="bg-white/80 backdrop-blur-lg border border-white/60 rounded-3xl p-6 sm:p-8 shadow-md space-y-4">
        <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
          Detailed Question Breakdown ({qaList.length})
        </h2>

        <div className="space-y-3">
          {qaList.map((item, idx) => {
            const isExpanded = expandedIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white/60 border border-slate-200/80 rounded-2xl overflow-hidden transition-all shadow-2xs"
              >
                <button
                  onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                  className="w-full p-4 flex items-center justify-between text-left hover:bg-slate-50/60 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-full bg-blue-100 text-blue-800 font-bold text-xs flex items-center justify-center shrink-0">
                      Q{idx + 1}
                    </span>
                    <div>
                      <p className="font-semibold text-slate-900 text-sm line-clamp-1">"{item.question}"</p>
                      <span className="text-[11px] text-slate-500">{item.category}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                      (item.evaluation?.score || 0) >= 8
                        ? 'bg-green-100 text-green-700'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {item.evaluation?.score || '—'}/10
                    </span>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </button>

                {isExpanded && item.evaluation && (
                  <div className="p-4 bg-slate-50/60 border-t border-slate-100 space-y-3 text-xs">
                    <div>
                      <p className="font-bold text-slate-400 uppercase tracking-wider text-[10px]">Your Answer:</p>
                      <p className="text-slate-700 italic bg-white p-3 rounded-xl border border-slate-200/60 mt-1">
                        "{item.userAnswer}"
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="bg-white p-3 rounded-xl border border-green-100 space-y-1">
                        <p className="font-bold text-green-700 uppercase text-[10px]">Strengths</p>
                        <ul className="list-disc pl-4 text-slate-600 space-y-0.5">
                          {item.evaluation.strengths.map((s, i) => <li key={i}>{s}</li>)}
                        </ul>
                      </div>

                      <div className="bg-white p-3 rounded-xl border border-amber-100 space-y-1">
                        <p className="font-bold text-amber-700 uppercase text-[10px]">Weaknesses</p>
                        <ul className="list-disc pl-4 text-slate-600 space-y-0.5">
                          {item.evaluation.weaknesses.map((w, i) => <li key={i}>{w}</li>)}
                        </ul>
                      </div>
                    </div>

                    <div className="bg-blue-50/40 p-3 rounded-xl border border-blue-100 space-y-1">
                      <p className="font-bold text-blue-700 uppercase text-[10px]">Ideal Sample Answer</p>
                      <p className="text-slate-800">{item.evaluation.betterAnswer}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Action Footer Bar */}
      <footer className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <button
          onClick={handlePrint}
          className="w-full sm:w-auto px-6 py-3.5 bg-white border border-slate-200 text-slate-700 font-bold text-sm rounded-xl hover:bg-slate-50 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Download className="w-4 h-4 text-slate-500" />
          <span>Export / Print Report</span>
        </button>

        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          <button
            onClick={onRestartSameSetup}
            className="px-6 py-3.5 bg-white border border-blue-200 text-blue-700 font-bold text-sm rounded-xl hover:bg-blue-50 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Practice Same Level Again</span>
          </button>

          <button
            onClick={onNewInterview}
            className="px-8 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Start New Setup</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
