import React from 'react';
import { STAR_GUIDE_ITEMS } from '../data/fallbackQuestions';
import { X, CheckCircle2, Sparkles, BookOpen } from 'lucide-react';

interface StarGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StarGuideModal: React.FC<StarGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-fade-in">
      <div 
        className="bg-white/95 backdrop-blur-xl border border-white/60 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Master the STAR Method</h2>
              <p className="text-xs text-slate-500">The gold standard framework for answering behavioral interview questions</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {STAR_GUIDE_ITEMS.map((item, idx) => (
            <div key={idx} className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center">
                  {item.title.charAt(0)}
                </span>
                <h3 className="font-bold text-slate-900 text-sm">{item.title}</h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed pl-8">
                {item.description}
              </p>
              <div className="pl-8 bg-blue-50/50 p-2.5 rounded-xl border border-blue-100/60 text-[11px] text-blue-900 italic">
                <strong className="not-italic font-semibold text-blue-700">Graduate Example: </strong>
                "{item.example}"
              </div>
            </div>
          ))}
        </div>

        <div className="bg-blue-600 text-white p-4 rounded-2xl flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <p className="font-bold text-xs uppercase tracking-wider text-blue-200">Pro Tip for Students</p>
            <p className="text-xs text-blue-50">Spend 50% of your total speaking time on the <strong>Action</strong> step—recruiters want to know what YOU personally did!</p>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-white text-blue-900 font-bold text-xs rounded-xl hover:bg-blue-50 cursor-pointer transition-all whitespace-nowrap shrink-0"
          >
            Got It!
          </button>
        </div>
      </div>
    </div>
  );
};
