import React from 'react';
import { Sparkles, ArrowRight, CheckCircle2, Award, Zap, Brain, ShieldCheck, Target, Users, BookOpen } from 'lucide-react';

interface HomePageProps {
  onStartInterview: () => void;
  onOpenStarGuide: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onStartInterview, onOpenStarGuide }) => {
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Main Hero Card */}
      <section className="bg-white/70 backdrop-blur-lg border border-white/60 rounded-3xl p-6 sm:p-10 shadow-md relative overflow-hidden">
        {/* Subtle Background Glow Spheres */}
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-blue-400/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-64 h-64 bg-indigo-400/15 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-3xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-blue-100/80 border border-blue-200/80 rounded-full text-blue-800 text-xs font-bold tracking-wide shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>AI-Powered HR Interview Simulator for Fresh Graduates</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            InterviewAce <span className="text-blue-600">AI</span>
          </h1>

          <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed font-normal">
            Practice HR interviews with AI and improve your confidence. Receive instant 10-point scoring, strengths, weaknesses, STAR framework tips, and ideal sample answers.
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={onStartInterview}
              className="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-base rounded-2xl shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all transform hover:-translate-y-0.5 cursor-pointer"
            >
              <span>Start Interview</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              onClick={onOpenStarGuide}
              className="w-full sm:w-auto px-6 py-4 bg-white/80 hover:bg-white border border-slate-200 text-slate-700 font-bold text-base rounded-2xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-blue-600" />
              <span>Learn STAR Method</span>
            </button>
          </div>

          {/* Target Audience Badges */}
          <div className="pt-4 border-t border-slate-200/50 flex flex-wrap justify-center items-center gap-3 text-xs font-semibold text-slate-500">
            <span className="flex items-center gap-1.5 bg-white/60 px-3 py-1 rounded-lg border border-white/80">
              <Users className="w-3.5 h-3.5 text-blue-600" /> University Students
            </span>
            <span className="flex items-center gap-1.5 bg-white/60 px-3 py-1 rounded-lg border border-white/80">
              <Target className="w-3.5 h-3.5 text-blue-600" /> Fresh Graduates
            </span>
            <span className="flex items-center gap-1.5 bg-white/60 px-3 py-1 rounded-lg border border-white/80">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" /> Internship Applicants
            </span>
          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/50 backdrop-blur-md border border-white/40 rounded-3xl p-6 shadow-xs hover:shadow-md transition-all group">
          <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center mb-4 text-blue-600 group-hover:scale-110 transition-transform">
            <Brain className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-blue-950 mb-2">1. One Question at a Time</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Answer realistic behavioral and HR interview questions tailored to your chosen level (Beginner, Intermediate, or Advanced).
          </p>
        </div>

        <div className="bg-white/50 backdrop-blur-md border border-white/40 rounded-3xl p-6 shadow-xs hover:shadow-md transition-all group">
          <div className="w-12 h-12 bg-indigo-100 rounded-2xl flex items-center justify-center mb-4 text-indigo-600 group-hover:scale-110 transition-transform">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-blue-950 mb-2">2. Instant AI Evaluation</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Get immediate feedback including a score out of 10, key strengths, areas missing, actionable improvement tips, and a better sample answer.
          </p>
        </div>

        <div className="bg-white/50 backdrop-blur-md border border-white/40 rounded-3xl p-6 shadow-xs hover:shadow-md transition-all group">
          <div className="w-12 h-12 bg-sky-100 rounded-2xl flex items-center justify-center mb-4 text-sky-600 group-hover:scale-110 transition-transform">
            <Zap className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-blue-950 mb-2">3. End-Session Performance Report</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Review your overall average score, strengths, readiness index, and actionable steps to land campus placements and top entry-level offers.
          </p>
        </div>
      </div>

      {/* Interactive Starter Preview Section */}
      <section className="bg-blue-600 text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-blue-400/30 rounded-full blur-2xl" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left max-w-xl">
            <div className="inline-block bg-blue-500/50 text-blue-100 text-xs font-bold px-3 py-1 rounded-md uppercase tracking-wider">
              Ace Tip #1
            </div>
            <h3 className="text-xl sm:text-2xl font-bold">Structure with the STAR Method</h3>
            <p className="text-blue-100 text-sm leading-relaxed">
              Top recruiters look for Situation, Task, Action, and Result in behavioral answers. InterviewAce AI guides you through each component seamlessly.
            </p>
          </div>
          <button
            onClick={onStartInterview}
            className="px-6 py-3.5 bg-white text-blue-900 font-bold text-sm rounded-xl hover:bg-blue-50 shadow-md transition-all cursor-pointer whitespace-nowrap"
          >
            Start Your Free Session
          </button>
        </div>
      </section>
    </div>
  );
};
