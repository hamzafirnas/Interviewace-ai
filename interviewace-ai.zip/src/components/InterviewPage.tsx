import React, { useState, useEffect, useRef } from 'react';
import { InterviewSetup, QuestionContext, AnswerEvaluation, InterviewQA } from '../types/interview';
import { fetchQuestionFromGemini, evaluateAnswerWithGemini } from '../services/geminiService';
import { ACE_TIPS } from '../data/fallbackQuestions';
import { Sparkles, Mic, MicOff, Volume2, ArrowRight, Loader2, CheckCircle, AlertTriangle, Lightbulb, RefreshCw, StopCircle } from 'lucide-react';

interface InterviewPageProps {
  setup: InterviewSetup;
  qaList: InterviewQA[];
  currentQAIndex: number;
  onAnswerSubmitted: (qa: InterviewQA) => void;
  onNextQuestion: () => void;
  onEndInterview: () => void;
  onOpenStarGuide: () => void;
}

export const InterviewPage: React.FC<InterviewPageProps> = ({
  setup,
  qaList,
  currentQAIndex,
  onAnswerSubmitted,
  onNextQuestion,
  onEndInterview,
  onOpenStarGuide
}) => {
  const currentQA = qaList[currentQAIndex] || null;
  const [userAnswer, setUserAnswer] = useState('');
  const [isLoadingQuestion, setIsLoadingQuestion] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [currentQuestionContext, setCurrentQuestionContext] = useState<QuestionContext | null>(null);
  
  // Speech Synthesis & Recognition state
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Rotating Ace Tip
  const aceTip = ACE_TIPS[currentQAIndex % ACE_TIPS.length];

  // Calculate average score so far
  const evaluatedScores = qaList
    .map(item => item.evaluation?.score)
    .filter((s): s is number => typeof s === 'number');
  
  const avgScore = evaluatedScores.length > 0
    ? (evaluatedScores.reduce((a, b) => a + b, 0) / evaluatedScores.length).toFixed(1)
    : '—';

  // Load question if not already in qaList
  useEffect(() => {
    let isMounted = true;

    async function loadQuestion() {
      if (!currentQA) {
        setIsLoadingQuestion(true);
        const previousQuestions = qaList.map(q => q.question);
        const qContext = await fetchQuestionFromGemini(
          setup.difficulty,
          setup.category,
          previousQuestions,
          currentQAIndex + 1
        );
        if (isMounted) {
          setCurrentQuestionContext(qContext);
          setIsLoadingQuestion(false);
        }
      } else {
        setUserAnswer(currentQA.userAnswer || '');
        setCurrentQuestionContext({
          question: currentQA.question,
          category: currentQA.category,
          contextTip: currentQA.contextTip,
          idealAspects: []
        });
      }
    }

    loadQuestion();

    return () => {
      isMounted = false;
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [currentQAIndex, setup.difficulty, setup.category]);

  // Speech TTS handler
  const handleSpeakQuestion = () => {
    if (!currentQuestionContext?.question) return;
    if (!('speechSynthesis' in window)) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentQuestionContext.question);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  // Speech Recognition (Dictation) handler
  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input is not supported in this browser. You can type your response in the text area.");
      return;
    }

    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setUserAnswer(prev => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error("Failed to start speech recognition:", err);
      setIsListening(false);
    }
  };

  // Submit Answer for AI Review
  const handleSubmitAnswer = async () => {
    if (!userAnswer.trim() || !currentQuestionContext) return;
    
    setIsEvaluating(true);
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (isListening && recognitionRef.current) recognitionRef.current.stop();

    const evaluation = await evaluateAnswerWithGemini(
      setup.userName,
      setup.difficulty,
      setup.category,
      currentQuestionContext.question,
      currentQuestionContext.contextTip,
      userAnswer.trim()
    );

    const completedQA: InterviewQA = {
      questionNumber: currentQAIndex + 1,
      question: currentQuestionContext.question,
      category: currentQuestionContext.category,
      contextTip: currentQuestionContext.contextTip,
      userAnswer: userAnswer.trim(),
      evaluation,
      answeredAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setIsEvaluating(false);
    onAnswerSubmitted(completedQA);
  };

  const isEvaluated = Boolean(currentQA?.evaluation);

  return (
    <div className="flex flex-col lg:flex-row gap-6 animate-fade-in">
      {/* Sidebar Section */}
      <aside className="w-full lg:w-72 flex flex-col gap-4 shrink-0">
        <div className="bg-white/50 backdrop-blur-md border border-white/40 rounded-3xl p-6 shadow-sm">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-4">
            Interview Session
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-xs text-slate-500">Difficulty</p>
                <p className="font-semibold text-blue-600 text-sm">{setup.difficulty}</p>
              </div>
              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-[10px] rounded-md font-bold uppercase tracking-wider">
                AI ACTIVE
              </span>
            </div>

            <div className="h-px bg-slate-200/50" />

            <div>
              <p className="text-xs text-slate-500">Progress</p>
              <p className="font-semibold text-slate-900 text-sm">
                Question {currentQAIndex + 1} of {setup.questionCount}
              </p>
              <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
                <div
                  className="bg-blue-600 h-full transition-all duration-500"
                  style={{ width: `${((currentQAIndex + 1) / setup.questionCount) * 100}%` }}
                />
              </div>
            </div>

            <div className="h-px bg-slate-200/50" />

            <div>
              <p className="text-xs text-slate-500">Avg Score</p>
              <p className="text-2xl font-bold text-blue-900">
                {avgScore}
                <span className="text-xs font-normal text-slate-400">/10</span>
              </p>
            </div>
          </div>
        </div>

        {/* Ace Tip Sidebar Box */}
        <div className="flex-1 bg-blue-600 rounded-3xl p-6 text-white relative overflow-hidden shadow-lg min-h-[160px]">
          <div className="relative z-10 space-y-2">
            <div className="flex items-center gap-1.5 text-blue-200 text-xs font-bold uppercase tracking-wider">
              <Lightbulb className="w-4 h-4 text-amber-300" />
              <span>Ace Tip</span>
            </div>
            <p className="text-blue-100 text-xs leading-relaxed italic">
              "{aceTip}"
            </p>
          </div>
          <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-blue-400/20 rounded-full blur-2xl" />
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col gap-4">
        <section className="bg-white/80 backdrop-blur-lg border border-white/60 rounded-3xl p-6 sm:p-8 shadow-md flex-1 flex flex-col space-y-6">
          {/* Question Header Card */}
          {isLoadingQuestion ? (
            <div className="flex flex-col items-center justify-center py-12 space-y-3">
              <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
              <p className="text-sm font-medium text-slate-600">Generating tailored HR question...</p>
            </div>
          ) : (
            <div className="space-y-3 text-center sm:text-left">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-blue-600 uppercase tracking-[0.2em] block">
                  Current Question #{currentQAIndex + 1}
                </span>
                {currentQuestionContext?.category && (
                  <span className="px-2.5 py-0.5 bg-slate-100 text-slate-600 text-[11px] font-semibold rounded-lg border border-slate-200">
                    {currentQuestionContext.category}
                  </span>
                )}
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-blue-50/40 p-4 rounded-2xl border border-blue-100/60">
                <h2 className="text-lg sm:text-2xl font-semibold text-slate-900 leading-snug flex-1">
                  "{currentQuestionContext?.question}"
                </h2>
                <button
                  onClick={handleSpeakQuestion}
                  className={`p-2.5 rounded-xl border transition-all cursor-pointer shrink-0 ${
                    isSpeaking 
                      ? 'bg-blue-600 text-white border-blue-600' 
                      : 'bg-white text-slate-600 hover:text-blue-600 border-slate-200 shadow-2xs'
                  }`}
                  title={isSpeaking ? "Stop listening" : "Listen to question"}
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>

              {currentQuestionContext?.contextTip && (
                <p className="text-xs text-slate-500 italic bg-white/60 px-3 py-2 rounded-xl border border-white/80">
                  💡 <strong>Interviewer Context:</strong> {currentQuestionContext.contextTip}
                </p>
              )}
            </div>
          )}

          {/* User Answer Input / Submission Area */}
          {!isEvaluated ? (
            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <span>Your Answer</span>
                  <span className="text-slate-400 font-normal">
                    ({userAnswer.trim().split(/\s+/).filter(Boolean).length} words)
                  </span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    onClick={onOpenStarGuide}
                    className="text-[11px] font-bold text-blue-600 hover:underline cursor-pointer"
                  >
                    Use STAR Checklist
                  </button>
                  <button
                    onClick={toggleListening}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                      isListening
                        ? 'bg-red-500 text-white border-red-600 animate-pulse'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-blue-600" />}
                    <span>{isListening ? "Listening..." : "Mic Dictation"}</span>
                  </button>
                </div>
              </div>

              <textarea
                rows={5}
                value={userAnswer}
                onChange={(e) => setUserAnswer(e.target.value)}
                placeholder="Type your answer here or click 'Mic Dictation' to speak out loud... Remember to include Situation, Task, Action, and Result."
                className="w-full p-4 bg-white/90 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 font-normal text-sm leading-relaxed placeholder-slate-400 shadow-2xs transition-all resize-none"
              />

              <button
                onClick={handleSubmitAnswer}
                disabled={!userAnswer.trim() || isEvaluating || isLoadingQuestion}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
              >
                {isEvaluating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>AI is Evaluating Your Answer...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Submit Answer for AI Review</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            /* AI Feedback Container (Matches Frosted Glass design template) */
            <div className="flex-1 bg-slate-50/60 rounded-2xl border border-slate-200/80 p-5 flex flex-col space-y-4 animate-fade-in">
              <div className="flex flex-wrap justify-between items-center gap-2 pb-2 border-b border-slate-200/60">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  AI FEEDBACK & SCORING
                </span>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-bold px-3 py-1 rounded-full ${
                    (currentQA.evaluation?.score || 0) >= 8
                      ? 'bg-green-100 text-green-700'
                      : (currentQA.evaluation?.score || 0) >= 6
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    Score: {currentQA.evaluation?.score}/10
                  </span>
                </div>
              </div>

              {/* User Submitted Answer Review */}
              <div className="bg-white/80 rounded-xl p-3 border border-slate-200/60 text-xs">
                <p className="font-bold text-slate-400 uppercase tracking-wider text-[10px] mb-1">Your Submitted Answer</p>
                <p className="text-slate-700 italic leading-relaxed">"{currentQA.userAnswer}"</p>
              </div>

              {/* Strengths & Weaknesses 2-Column Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white/70 rounded-xl p-3.5 border border-green-200/60 shadow-2xs space-y-1.5">
                  <p className="text-[11px] font-bold text-green-700 uppercase flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> Strengths
                  </p>
                  <ul className="space-y-1 text-xs text-slate-600 list-disc pl-4">
                    {currentQA.evaluation?.strengths.map((str, idx) => (
                      <li key={idx}>{str}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-white/70 rounded-xl p-3.5 border border-amber-200/60 shadow-2xs space-y-1.5">
                  <p className="text-[11px] font-bold text-amber-700 uppercase flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Areas to Improve
                  </p>
                  <ul className="space-y-1 text-xs text-slate-600 list-disc pl-4">
                    {currentQA.evaluation?.weaknesses.map((wk, idx) => (
                      <li key={idx}>{wk}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Actionable Tips */}
              {currentQA.evaluation?.tips && currentQA.evaluation.tips.length > 0 && (
                <div className="bg-blue-50/50 rounded-xl p-3 border border-blue-100/80 text-xs text-blue-900 space-y-1">
                  <p className="font-bold text-blue-700 uppercase text-[11px]">💡 Improvement Tips</p>
                  <ul className="list-disc pl-4 space-y-0.5 text-slate-700">
                    {currentQA.evaluation.tips.map((tip, idx) => (
                      <li key={idx}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Better Sample Answer Box */}
              <div className="bg-blue-50/40 rounded-xl p-4 border border-blue-100/80 space-y-1.5">
                <p className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">
                  Better Sample Answer (STAR Model)
                </p>
                <p className="text-xs leading-relaxed text-slate-800 font-medium">
                  "{currentQA.evaluation?.betterAnswer}"
                </p>
              </div>

              {/* Key Takeaway */}
              {currentQA.evaluation?.keyTakeaway && (
                <p className="text-[11px] font-semibold text-slate-500 text-center italic pt-1">
                  Summary Takeaway: {currentQA.evaluation.keyTakeaway}
                </p>
              )}
            </div>
          )}
        </section>

        {/* Footer Navigation Bar (Matches Frosted Glass template) */}
        <footer className="h-20 flex justify-between items-center px-4 sm:px-8 bg-white/40 backdrop-blur-md border border-white/20 rounded-3xl shadow-sm gap-4">
          <button
            onClick={onEndInterview}
            className="text-slate-500 font-semibold text-xs sm:text-sm hover:text-red-600 transition-colors cursor-pointer"
          >
            End Interview
          </button>

          <div className="flex gap-3">
            {isEvaluated && (
              <button
                onClick={onNextQuestion}
                className="px-6 sm:px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>{currentQAIndex + 1 < setup.questionCount ? "Next Question" : "View Final Summary"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </footer>
      </main>
    </div>
  );
};
