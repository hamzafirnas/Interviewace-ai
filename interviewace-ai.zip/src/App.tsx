/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppView, InterviewSetup, InterviewQA } from './types/interview';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { SetupPage } from './components/SetupPage';
import { InterviewPage } from './components/InterviewPage';
import { SummaryPage } from './components/SummaryPage';
import { StarGuideModal } from './components/StarGuideModal';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [setup, setSetup] = useState<InterviewSetup>({
    userName: '',
    difficulty: 'Intermediate',
    category: 'General HR & Campus Hire',
    questionCount: 5
  });

  const [qaList, setQaList] = useState<InterviewQA[]>([]);
  const [currentQAIndex, setCurrentQAIndex] = useState<number>(0);
  const [isStarGuideOpen, setIsStarGuideOpen] = useState<boolean>(false);

  // Handlers
  const handleStartSetup = () => {
    setCurrentView('setup');
  };

  const handleStartInterview = (newSetup: InterviewSetup) => {
    setSetup(newSetup);
    setQaList([]);
    setCurrentQAIndex(0);
    setCurrentView('interview');
  };

  const handleAnswerSubmitted = (completedQA: InterviewQA) => {
    setQaList(prev => {
      const updated = [...prev];
      updated[currentQAIndex] = completedQA;
      return updated;
    });
  };

  const handleNextQuestion = () => {
    if (currentQAIndex + 1 < setup.questionCount) {
      setCurrentQAIndex(prev => prev + 1);
    } else {
      setCurrentView('summary');
    }
  };

  const handleEndInterview = () => {
    if (qaList.length > 0) {
      setCurrentView('summary');
    } else {
      setCurrentView('home');
    }
  };

  const handleRestartSameSetup = () => {
    setQaList([]);
    setCurrentQAIndex(0);
    setCurrentView('interview');
  };

  const handleNewInterview = () => {
    setQaList([]);
    setCurrentQAIndex(0);
    setCurrentView('setup');
  };

  const handleResetSession = () => {
    if (confirm("Are you sure you want to restart this interview session? Your current progress will be cleared.")) {
      setQaList([]);
      setCurrentQAIndex(0);
      setCurrentView('setup');
    }
  };

  // Compute average score so far for Navbar
  const evaluatedScores = qaList
    .map(q => q.evaluation?.score)
    .filter((s): s is number => typeof s === 'number');
  const avgScore = evaluatedScores.length > 0
    ? evaluatedScores.reduce((a, b) => a + b, 0) / evaluatedScores.length
    : undefined;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-100 text-slate-800 font-sans p-4 sm:p-6 flex flex-col justify-between selection:bg-blue-200">
      <div className="max-w-7xl w-full mx-auto flex-1 flex flex-col">
        {/* Navbar */}
        <Navbar
          currentView={currentView}
          setup={setup}
          currentQAIndex={currentQAIndex}
          totalQuestions={setup.questionCount}
          averageScore={avgScore}
          onNavigate={(view) => setCurrentView(view)}
          onOpenStarGuide={() => setIsStarGuideOpen(true)}
          onResetSession={handleResetSession}
        />

        {/* Dynamic Views */}
        <div className="flex-1">
          {currentView === 'home' && (
            <HomePage
              onStartInterview={handleStartSetup}
              onOpenStarGuide={() => setIsStarGuideOpen(true)}
            />
          )}

          {currentView === 'setup' && (
            <SetupPage
              initialSetup={setup}
              onStartInterview={handleStartInterview}
              onBackToHome={() => setCurrentView('home')}
            />
          )}

          {currentView === 'interview' && (
            <InterviewPage
              setup={setup}
              qaList={qaList}
              currentQAIndex={currentQAIndex}
              onAnswerSubmitted={handleAnswerSubmitted}
              onNextQuestion={handleNextQuestion}
              onEndInterview={handleEndInterview}
              onOpenStarGuide={() => setIsStarGuideOpen(true)}
            />
          )}

          {currentView === 'summary' && (
            <SummaryPage
              setup={setup}
              qaList={qaList}
              onRestartSameSetup={handleRestartSameSetup}
              onNewInterview={handleNewInterview}
            />
          )}
        </div>
      </div>

      {/* Footer Disclaimer */}
      <footer className="mt-8 pt-4 border-t border-slate-200/50 text-center text-xs text-slate-500 max-w-7xl mx-auto w-full">
        <p>
          InterviewAce AI © {new Date().getFullYear()} — Powered by Gemini AI. Empowering university students and fresh graduates to excel in HR interviews.
        </p>
      </footer>

      {/* STAR Response Framework Guide Modal */}
      <StarGuideModal
        isOpen={isStarGuideOpen}
        onClose={() => setIsStarGuideOpen(false)}
      />
    </div>
  );
}
