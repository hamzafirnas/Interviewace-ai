export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export type JobCategory = 
  | 'General HR & Campus Hire'
  | 'Software Engineering & Tech'
  | 'Business Development & Marketing'
  | 'Finance & Accounting'
  | 'Management Trainee & Ops';

export interface InterviewSetup {
  userName: string;
  difficulty: DifficultyLevel;
  category: JobCategory;
  questionCount: number;
}

export interface QuestionContext {
  question: string;
  category: string;
  contextTip: string;
  idealAspects: string[];
}

export interface AnswerEvaluation {
  score: number; // 1 to 10
  strengths: string[];
  weaknesses: string[];
  tips: string[];
  betterAnswer: string;
  keyTakeaway: string;
}

export interface InterviewQA {
  questionNumber: number;
  question: string;
  category: string;
  contextTip: string;
  userAnswer: string;
  evaluation?: AnswerEvaluation;
  answeredAt?: string;
}

export interface InterviewSummaryReport {
  averageScore: number;
  totalQuestions: number;
  overallFeedback: string;
  topStrengths: string[];
  areasToImprove: string[];
  readinessRating: string;
  actionSteps: string[];
}

export type AppView = 'home' | 'setup' | 'interview' | 'summary';
