import { InterviewQA, QuestionContext, AnswerEvaluation } from '../types/interview';

export const STAR_GUIDE_ITEMS = [
  {
    title: "Situation (S)",
    description: "Set the scene and give necessary context. Where were you working or studying, and what was the scenario?",
    example: "During my senior capstone project with a team of four students..."
  },
  {
    title: "Task (T)",
    description: "Explain the goal, challenge, or responsibility you had to address.",
    example: "We had a strict 2-week deadline to build a functional prototype, but two members disagreed on the framework."
  },
  {
    title: "Action (A)",
    description: "Describe the specific steps YOU took to address the problem. Emphasize your individual contribution.",
    example: "I organized a 1-on-1 discussion to list pros/cons against project requirements and proposed a compromise solution."
  },
  {
    title: "Result (R)",
    description: "Share the outcome. Quantify results with metrics or specific positive impacts whenever possible.",
    example: "We reached a consensus, submitted the project 2 days early, and scored 95/100 on the final evaluation."
  }
];

export const ACE_TIPS = [
  "Use the STAR method (Situation, Task, Action, Result) to structure behavioral questions cleanly.",
  "Keep your answer between 1.5 to 2 minutes (approx. 150-250 words) to remain concise yet thorough.",
  "Highlight specific metrics or outcomes (e.g. 'improved efficiency by 20%' or 'scored 95/100').",
  "Frame past failures as learning opportunities—focus 80% of your answer on your solution and growth.",
  "Speak with enthusiasm about your projects; interviewers evaluate culture fit alongside technical skill.",
  "Maintain clear structure: state your main point upfront, back it up with a story, and conclude with the key takeaway."
];

export const SAMPLE_QUESTIONS: Record<string, QuestionContext[]> = {
  'Beginner': [
    {
      question: "Tell me about yourself and why you are interested in this position.",
      category: "Self Introduction & Motivation",
      contextTip: "Focus on your academic background, relevant projects, and key skills that align with the role.",
      idealAspects: ["Present education", "Relevant project or internship experience", "Why this company aligns with career goals"]
    },
    {
      question: "What do you consider to be your greatest strength and your biggest area for growth?",
      category: "Self Awareness",
      contextTip: "Choose a strength relevant to the job, and an area for growth where you are actively improving.",
      idealAspects: ["Specific professional strength with example", "Genuine growth area", "Action steps taken to improve"]
    },
    {
      question: "Why do you want to work for our company out of all the options available to fresh graduates?",
      category: "Company Interest & Cultural Fit",
      contextTip: "Show that you researched our company culture, values, or recent products/achievements.",
      idealAspects: ["Company research evidence", "Alignment with personal values", "Eagerness to contribute"]
    }
  ],
  'Intermediate': [
    {
      question: "Tell me about a time you had to deal with a conflict within a team project. How did you resolve it?",
      category: "Conflict Resolution & Teamwork",
      contextTip: "Use the STAR method. Focus on empathy, open communication, and reaching a productive consensus.",
      idealAspects: ["Clear situation context", "Direct constructive action taken", "Positive measurable outcome"]
    },
    {
      question: "Describe a situation where you had to manage multiple tight deadlines for university courses or projects. How did you prioritize?",
      category: "Time Management & Prioritization",
      contextTip: "Explain your framework or tools for prioritization under pressure.",
      idealAspects: ["Prioritization matrix or plan", "Communication with team/professors", "Successful delivery of all tasks"]
    },
    {
      question: "Give an example of a time when a project or assignment didn't go as planned. What went wrong and how did you adapt?",
      category: "Resilience & Problem Solving",
      contextTip: "Be honest about the challenge, but focus heavily on your pivot and what you learned.",
      idealAspects: ["Ownership of situation", "Agile adaptability", "Key lessons learned for future work"]
    }
  ],
  'Advanced': [
    {
      question: "Describe a scenario where you had to lead a project team with unclear requirements or conflicting stakeholder expectations.",
      category: "Leadership & Navigating Ambiguity",
      contextTip: "Demonstrate proactive communication, setting milestones, and keeping stakeholders aligned.",
      idealAspects: ["Clarification process", "Stakeholder alignment strategy", "Delivery despite ambiguity"]
    },
    {
      question: "Tell me about a time you received constructive criticism from a mentor or manager that you initially disagreed with. How did you handle it?",
      category: "Emotional Intelligence & Coachability",
      contextTip: "Show humility, openness to feedback, and how you evaluated the feedback objectively.",
      idealAspects: ["Initial reaction control", "Objective reflection", "Positive implementation of feedback"]
    },
    {
      question: "Give an example of how you convinced peers or team members to adopt a new tool, method, or strategy that they were resistant to.",
      category: "Persuasion & Change Management",
      contextTip: "Focus on data-driven reasoning, empathy for their concerns, and running a pilot demonstration.",
      idealAspects: ["Understanding resistance", "Data or demo proof", "Successful adoption outcome"]
    }
  ]
};

export const FALLBACK_EVALUATION: AnswerEvaluation = {
  score: 8.5,
  strengths: [
    "Used a clear structured approach describing the conflict and outcome.",
    "Showed emotional intelligence and empathy when addressing team members.",
    "Highlighted proactive communication to keep the team focused on goals."
  ],
  weaknesses: [
    "Could provide more specific numerical details on time saved or project deliverables.",
    "Initial context setup was slightly wordy before reaching the core action."
  ],
  tips: [
    "Structure using explicit STAR steps: Situation (15%), Task (15%), Action (50%), Result (20%).",
    "Quantify your results (e.g. 'delivered 2 days ahead of deadline' or 'boosted test coverage by 25%')."
  ],
  betterAnswer: "During my senior capstone project, two members disagreed on the technical stack, stalling progress. I initiated a brief 1-on-1 with both to understand their concerns, then facilitated a group meeting where we evaluated both options against our project constraints. We reached a consensus by combining key features, allowing us to submit our project two days ahead of schedule with an 'A' grade.",
  keyTakeaway: "Great demonstration of leadership and empathy—quantify the final result to make it flawless!"
};
