import { GoogleGenAI, Type } from '@google/genai';
import { DifficultyLevel, JobCategory, QuestionContext, AnswerEvaluation, InterviewQA, InterviewSummaryReport } from '../types/interview';
import { SAMPLE_QUESTIONS, FALLBACK_EVALUATION } from '../data/fallbackQuestions';

// Get API Key safely from environment or Vite env
const getApiKey = (): string => {
  if (typeof process !== 'undefined' && process.env && process.env.GEMINI_API_KEY) {
    return process.env.GEMINI_API_KEY;
  }
  if (typeof window !== 'undefined' && (import.meta as any).env?.VITE_GEMINI_API_KEY) {
    return (import.meta as any).env.VITE_GEMINI_API_KEY;
  }
  return '';
};

const getAiClient = () => {
  const apiKey = getApiKey();
  return new GoogleGenAI({ apiKey: apiKey || 'DUMMY_KEY_FOR_FALLBACK' });
};

/**
 * Generate a new HR Interview Question tailored for University Students & Fresh Graduates
 */
export async function fetchQuestionFromGemini(
  difficulty: DifficultyLevel,
  category: JobCategory,
  previousQuestions: string[],
  questionNumber: number
): Promise<QuestionContext> {
  try {
    const apiKey = getApiKey();
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      console.warn("Gemini API key not configured. Using high-quality curated sample question.");
      return getFallbackQuestion(difficulty, previousQuestions, questionNumber);
    }

    const ai = getAiClient();
    const prompt = `
You are a senior HR Interviewer at a top global company interviewing a university student or fresh graduate candidate for an entry-level position or internship.

Candidate Details:
- Difficulty Level: ${difficulty}
- Role/Industry Focus: ${category}
- Question Number in Session: ${questionNumber}
- Questions already asked in this session (DO NOT repeat these): ${JSON.stringify(previousQuestions)}

Task:
Generate a realistic, high-impact HR or behavioral interview question appropriate for the specified difficulty level and category.
For Beginner: focus on motivation, self-awareness, basic teamwork, academic projects.
For Intermediate: focus on conflict resolution, handling pressure, adaptability, decision-making under constraints.
For Advanced: focus on leadership, handling ambiguity, stakeholder management, strategic alignment, learning from failure.

Return JSON adhering strictly to this format:
{
  "question": "The interview question text",
  "category": "e.g. Conflict Resolution & Teamwork",
  "contextTip": "Advice on how the candidate should approach this question (e.g. STAR method hint)",
  "idealAspects": ["Aspect 1", "Aspect 2", "Aspect 3"]
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            category: { type: Type.STRING },
            contextTip: { type: Type.STRING },
            idealAspects: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["question", "category", "contextTip", "idealAspects"]
        }
      }
    });

    if (response.text) {
      const parsed = JSON.parse(response.text);
      if (parsed.question) {
        return parsed as QuestionContext;
      }
    }
  } catch (error) {
    console.error("Error fetching question from Gemini:", error);
  }

  return getFallbackQuestion(difficulty, previousQuestions, questionNumber);
}

function getFallbackQuestion(
  difficulty: DifficultyLevel,
  previousQuestions: string[],
  questionNumber: number
): QuestionContext {
  const bank = SAMPLE_QUESTIONS[difficulty] || SAMPLE_QUESTIONS['Intermediate'];
  const unused = bank.filter(q => !previousQuestions.includes(q.question));
  if (unused.length > 0) {
    return unused[(questionNumber - 1) % unused.length];
  }
  return bank[(questionNumber - 1) % bank.length];
}

/**
 * Evaluate the candidate's answer with score, strengths, weaknesses, tips, and sample answer
 */
export async function evaluateAnswerWithGemini(
  userName: string,
  difficulty: DifficultyLevel,
  category: JobCategory,
  question: string,
  contextTip: string,
  userAnswer: string
): Promise<AnswerEvaluation> {
  try {
    const apiKey = getApiKey();
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      console.warn("Gemini API key not configured. Using fallback evaluation.");
      return generateRuleBasedEvaluation(userAnswer);
    }

    const ai = getAiClient();
    const prompt = `
You are an expert HR Interview Coach evaluating a candidate's answer to an HR interview question.

Candidate Name: ${userName || 'Candidate'}
Target Level: ${difficulty}
Role Category: ${category}
Interview Question: "${question}"
Context Advice: "${contextTip}"

Candidate's Submitted Answer:
"${userAnswer}"

Task:
Evaluate the response constructive, insightful, and encouraging manner tailored for university students and fresh graduates.
Difficulty evaluation guidance:
- Beginner: Encouraging grading scale, focus on basic structure and enthusiasm.
- Intermediate: Standard professional grading, check for STAR method (Situation, Task, Action, Result) and clear outcomes.
- Advanced: High expectations, check for leadership depth, metrics, strategic impact, and conciseness.

Criteria for Evaluation:
1. Score out of 10 (numeric integer or float e.g. 8.5).
2. Strengths: 2 to 3 bullet points highlighting what was done well (e.g., clear STAR structure, specific examples, good tone).
3. Weaknesses: 1 to 2 bullet points on what was missing or could be improved (e.g., missing metrics, slightly wordy, lacked clear result).
4. Tips for Improvement: 2 actionable advice points to improve this exact response or future answers.
5. Better Sample Answer: Write an exemplary, realistic 3 to 4 sentence sample answer that the student could model, following the STAR framework.
6. Key Takeaway: One short summary line.

Return strict JSON format:
{
  "score": 8.5,
  "strengths": ["...", "..."],
  "weaknesses": ["..."],
  "tips": ["...", "..."],
  "betterAnswer": "...",
  "keyTakeaway": "..."
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            weaknesses: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            betterAnswer: { type: Type.STRING },
            keyTakeaway: { type: Type.STRING }
          },
          required: ["score", "strengths", "weaknesses", "tips", "betterAnswer", "keyTakeaway"]
        }
      }
    });

    if (response.text) {
      const parsed = JSON.parse(response.text);
      if (typeof parsed.score === 'number') {
        return {
          score: Math.min(10, Math.max(1, Math.round(parsed.score * 10) / 10)),
          strengths: parsed.strengths || [],
          weaknesses: parsed.weaknesses || [],
          tips: parsed.tips || [],
          betterAnswer: parsed.betterAnswer || '',
          keyTakeaway: parsed.keyTakeaway || ''
        };
      }
    }
  } catch (error) {
    console.error("Error evaluating answer with Gemini:", error);
  }

  return generateRuleBasedEvaluation(userAnswer);
}

function generateRuleBasedEvaluation(userAnswer: string): AnswerEvaluation {
  const length = userAnswer.trim().length;
  let score = 7.5;
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const tips: string[] = [];

  if (length > 250) {
    score += 1.0;
    strengths.push("Provided a detailed and comprehensive explanation.");
  } else if (length > 100) {
    strengths.push("Gave a clear and direct answer.");
  } else {
    score -= 1.5;
    weaknesses.push("Response was quite brief; add more context using the STAR framework.");
  }

  const hasSituation = /when|during|at my|project|team|university|course/i.test(userAnswer);
  const hasAction = /i did|i organized|i created|i resolved|i communicated|i decided/i.test(userAnswer);
  const hasResult = /result|outcome|led to|succeeded|completed|learned|improved/i.test(userAnswer);

  if (hasSituation && hasAction && hasResult) {
    score += 1.0;
    strengths.push("Effectively covered Situation, Action, and Result components.");
  } else {
    tips.push("Make sure to explicitly state the 'Result' (what happened in the end and what you learned).");
  }

  if (userAnswer.length < 150) {
    tips.push("Aim for around 150-250 words to give the interviewer enough detail without rambling.");
  }

  return {
    score: Math.min(10, Math.max(5, Math.round(score * 10) / 10)),
    strengths: strengths.length ? strengths : FALLBACK_EVALUATION.strengths,
    weaknesses: weaknesses.length ? weaknesses : FALLBACK_EVALUATION.weaknesses,
    tips: tips.length ? tips : FALLBACK_EVALUATION.tips,
    betterAnswer: FALLBACK_EVALUATION.betterAnswer,
    keyTakeaway: FALLBACK_EVALUATION.keyTakeaway
  };
}

/**
 * Generate comprehensive final summary report at end of interview session
 */
export async function generateSummaryWithGemini(
  userName: string,
  difficulty: DifficultyLevel,
  category: JobCategory,
  qaList: InterviewQA[]
): Promise<InterviewSummaryReport> {
  const scores = qaList.map(q => q.evaluation?.score || 7);
  const avgScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 8;
  const roundedAvg = Math.round(avgScore * 10) / 10;

  try {
    const apiKey = getApiKey();
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
      const ai = getAiClient();
      const prompt = `
You are a Lead HR Consultant reviewing the complete mock interview performance for a graduate candidate.

Candidate Name: ${userName || 'Candidate'}
Difficulty: ${difficulty}
Role Category: ${category}
Average Score: ${roundedAvg} / 10
Questions and Answers evaluated:
${JSON.stringify(qaList.map(q => ({
  q: q.question,
  userAnswer: q.userAnswer,
  score: q.evaluation?.score,
  strengths: q.evaluation?.strengths,
  weaknesses: q.evaluation?.weaknesses
})))}

Generate an end-of-interview summary report in strict JSON adhering to:
{
  "overallFeedback": "Detailed paragraph giving constructive overall performance assessment and praise.",
  "topStrengths": ["Strength 1", "Strength 2", "Strength 3"],
  "areasToImprove": ["Area 1", "Area 2"],
  "readinessRating": "e.g. 'Campus Placement Ready' or 'Strong Potential with Minor Polish'",
  "actionSteps": ["Actionable step 1", "Actionable step 2", "Actionable step 3"]
}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallFeedback: { type: Type.STRING },
              topStrengths: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              areasToImprove: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              readinessRating: { type: Type.STRING },
              actionSteps: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["overallFeedback", "topStrengths", "areasToImprove", "readinessRating", "actionSteps"]
          }
        }
      });

      if (response.text) {
        const parsed = JSON.parse(response.text);
        return {
          averageScore: roundedAvg,
          totalQuestions: qaList.length,
          overallFeedback: parsed.overallFeedback,
          topStrengths: parsed.topStrengths || [],
          areasToImprove: parsed.areasToImprove || [],
          readinessRating: parsed.readinessRating || 'Ready for Interviews',
          actionSteps: parsed.actionSteps || []
        };
      }
    }
  } catch (error) {
    console.error("Error generating summary with Gemini:", error);
  }

  // Fallback report generator
  return {
    averageScore: roundedAvg,
    totalQuestions: qaList.length,
    overallFeedback: `${userName || 'Candidate'} demonstrated good communication skills and structure during this ${difficulty} level interview session. Answers showed solid engagement and relevant university or personal project experiences.`,
    topStrengths: [
      "Consistent enthusiasm and clear storytelling approach.",
      "Good structure addressing the main intent of the questions.",
      "Showed initiative in discussing academic and team scenarios."
    ],
    areasToImprove: [
      "Incorporate more quantifiable metrics (percentages, team sizes, deadlines) into answers.",
      "Refine conciseness to ensure answers wrap up within 2 minutes."
    ],
    readinessRating: roundedAvg >= 8.5 ? 'Campus Placement Ready' : roundedAvg >= 7.0 ? 'Strong Candidate — Minor Polish Needed' : 'Requires Further Practice',
    actionSteps: [
      "Practice 3 more STAR behavioral stories focused on problem-solving under pressure.",
      "Prepare 2 metric-rich bullet points for your top capstone project.",
      "Record yourself speaking out loud to refine vocal pacing and confidence."
    ]
  };
}
